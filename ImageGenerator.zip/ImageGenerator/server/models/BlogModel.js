const mongoose = require("mongoose");

// Define the Blog schema
const blogSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  prompt: {
    type: String,
  },
  image: {
    type: String,
  },
  heading: {
    type: String,
  },
  body: {
    type: String,
  },
  likes: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Like",
    },
  ],
  comments: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Comment",
    },
  ],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Export the Courses model
module.exports = mongoose.model("Blog", blogSchema);
