const express = require("express");
const WeatherReportGenerator = require("../../controllers/OtherC/WeatherReportGenerator");

const router = express.Router();

router.post("/", WeatherReportGenerator);

module.exports = router;
