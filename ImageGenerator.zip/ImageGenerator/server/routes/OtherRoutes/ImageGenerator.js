const express = require("express");
const ImageGenerator = require("../../controllers/OtherC/ImageGenerator");

const router = express.Router();

router.get("/", ImageGenerator);

module.exports = router;
