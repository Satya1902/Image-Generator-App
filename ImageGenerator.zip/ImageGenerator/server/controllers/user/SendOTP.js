const dotenv = require("dotenv");

const transporter = require("../../services/MailSenderTransporter");
const OtpModel = require("../../models/OTPModel");
const UserModel = require("../../models/UserModel");

dotenv.config();

async function sendOTP(req, res) {
  try {
    const { email, otp } = req.body;

    console.log("Inside sendOtp and email,otp are : ", email, otp);

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: " please share email , otp",
      });
    }

    const existingUser = await UserModel.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message:
          " User is already exist with this email Please Login or try with another email ",
      });
    }

    const data = await OtpModel.create({ email, otp });
    // console.log("Printing data that is stored in DB ", data);

    let info = await transporter.sendMail({
      from: "er.satyagautam@gmail.com",
      to: email,
      subject: "BLOG APP",
      html: `<h2> Your OTP is : ${otp}</h2>`,
    });

    return res.status(200).json({
      success: true,
      message: " OTP has been sent sccessfully ",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message:
        "Internal server error , Something went wrong while sending email ",
    });
  }
}

module.exports = sendOTP;
