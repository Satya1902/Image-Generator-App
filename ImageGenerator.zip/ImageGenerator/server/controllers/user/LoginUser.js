const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const bcrypt = require("bcryptjs");

const UserModel = require("../../models/UserModel");

dotenv.config();

const LoginUser = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: " All fields are mandaory !!",
      });
    }

    let existingUser = await UserModel.findOne({ email });

    if (!existingUser) {
      return res.status(401).json({
        success: false,
        message: " Please enter registered email id ",
      });
    }

    const payload = {
      email: existingUser.email,
      id: existingUser._id,
      role: existingUser.role,
    };

    const isMatchedPassword = await bcrypt.compare(
      password,
      existingUser.password
    );

    if (isMatchedPassword) {
      let token = jwt.sign(payload, process.env.JWT_SECRET, {
        expiresIn: "3h",
      });
      existingUser = existingUser.toObject();
      existingUser.token = token;
      existingUser.password = undefined;
      req.body.token = token;

      // res.user = existingUser;
      // next();

      return res.status(200).json({
        success: true,
        token,
        user: existingUser,
        message: "Welcome to the blog app,You have logged in successfully ",
      });

      // const options = {
      //   expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      //   // httpOnly : true
      // };
      // return res.cookie("token", token, options).status(200).json({
      //   success: true,
      //   message: " Your have Logged in successfully, Enjoy your Blog app ",
      //   user: existingUser,
      // });
      // next();
    } else {
      return res.status(400).json({
        success: false,
        message:
          " You have entered incorrect password, Please enter correct password  ",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Something went wrong while Login to BlogApp, Please try again ",
    });
  }
};

module.exports = LoginUser;
