const SavedImageModel = require("../../models/SavedImageModel");
const UserModel = require("../../models/UserModel");

async function saveImage(req, res) {
  const imageUrl = req.body.imageUrl;
  const user = req.body.user;

  if (!imageUrl || !user) {
    return res.status(400).json({
      success: false,
      message: "Image url and user is required !!!!!",
    });
  }

  console.log("imageUrl and user at saveImage is ", imageUrl, user);

  try {
    const userId = user.id;
    const userObject = await UserModel.findById(userId);

    // if image alrady added to saved image

    const existingSavedImage = await SavedImageModel.findOne({
      image: imageUrl,
    });

    if (existingSavedImage) {
      return res.status(409).json({
        success: false,
        message: "This image is already added to your savedImage !!!!!",
      });
    }

    const savedImage = await SavedImageModel.create({
      image: imageUrl,
      user: userObject,
    });

    const updateUser = await UserModel.findByIdAndUpdate(
      { _id: userId },
      { $push: { savedImages: savedImage } }
    );

    console.log("savedImage is : ", savedImage);

    return res.status(200).json({
      success: true,
      message:
        "Image has been uploaded to cloudinary and added to your saved images successfully",
    });
  } catch (error) {
    console.error("error", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error while uploading image to cloudinary",
    });
  }
}

module.exports = saveImage;
