import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  signupData: localStorage.getItem("signupData")
    ? JSON.parse(localStorage.getItem("signupData"))
    : null,
  otp: localStorage.getItem("otps")
    ? JSON.parse(localStorage.getItem("otps"))
    : null,
  profileImage: localStorage.getItem("profileImage")
    ? JSON.parse(localStorage.getItem("profileImage"))
    : null,
};

const signupSlice = createSlice({
  name: "signup",
  initialState: initialState,
  reducers: {
    setSignupData: (state, action) => {
      state.signupData = action.payload;
      localStorage.setItem("signupData", JSON.stringify(state.signupData));
    },
    setOtp: (state, action) => {
      state.otp = action.payload;
      localStorage.setItem("otps", JSON.stringify(state.otp));
    },
    setProfileImage: (state, action) => {
      state.profileImage = action.payload;
      localStorage.setItem("profileImage", JSON.stringify(state.profileImage));
    },
    removeOtp: (state, action) => {
      state.otp = action.payload;
      localStorage.removeItem("otps");
    },
    removeSignupData: (state, action) => {
      state.signupData = action.payload;
      localStorage.removeItem("signupData");
    },
    removeProfileImage: (state, action) => {
      state.profileImage = action.payload;
      localStorage.removeItem("profileImage");
    },
    resetSignup: () => {
      localStorage.removeItem("signupData");
      localStorage.removeItem("otps");
      localStorage.removeItem("profileImage");
    },
  },
});

export const {
  setSignupData,
  setOtp,
  setProfileImage,
  removeOtp,
  removeSignupDataStore,
  removeProfileImage,
  resetSignup,
} = signupSlice.actions;

export default signupSlice.reducer;
