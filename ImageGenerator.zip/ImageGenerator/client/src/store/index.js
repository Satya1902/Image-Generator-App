import { configureStore } from "@reduxjs/toolkit";

import authReducer from "./auth";
import postReducer from "./post";
import signupReducer from "./signup";
import blogReducer from "./yourBlogs";

const store = configureStore({
  reducer: {
    auth: authReducer,
    post: postReducer,
    signup: signupReducer,
    blog: blogReducer,
  },
});

export default store;
