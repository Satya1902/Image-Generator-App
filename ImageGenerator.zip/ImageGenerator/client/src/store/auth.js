import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  token:
    localStorage.getItem("tokens") &&
    localStorage.getItem("tokens") !== undefined &&
    Date.now() - JSON.parse(localStorage.getItem("tokens")).createdAt <=
      36000000
      ? JSON.parse(localStorage.getItem("tokens")).token
      : null,
};

const authSlice = createSlice({
  name: "auth",
  initialState: initialState,
  reducers: {
    setToken: (state, action) => {
      if (action.payload && action.payload !== undefined) {
        localStorage.setItem("tokens", JSON.stringify(action.payload));
        state.token = action.payload.token;
      }
    },
    removeToken: (state, action) => {
      localStorage.removeItem("tokens");
    },
    resetAuth: (state) => {
      state.token = null;
      localStorage.removeItem("tokens");
    },
  },
});

export const { setToken, removeToken, resetAuth } = authSlice.actions;

export default authSlice.reducer;
