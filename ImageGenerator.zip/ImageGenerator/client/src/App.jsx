import { Route, Routes } from "react-router-dom";

// import Navbar from "./components/common/Navbar";
import Login from "./pages/Login";
import Signup from "./pages/Signup/Signup";
import VarifyEmail from "./pages/Signup/VarifyEmail";
import SignupRoute from "./components/authentication/SignupProfileRoute";
import UserDashboard from "./pages/User/UserDashboard";
import PrivateRoute from "./components/authentication/PrivateRoute";
import GenerateImage from "./pages/User/GenerateImage";
import Home from "./pages/Home";
// import LoginRoute from "./components/authentication/LoginRoute";

import "./App.css";
import LikesOfParticularBlog from "./pages/User/LikesOfParticularBlog";
import ParticularBlog from "./pages/User/ParticularBlog";
import AddComment from "./pages/User/AddComment";
// import { useSelector } from "react-redux";

function App() {
  // localStorage.removeItem("token");
  // localStorage.removeItem("otp");

  if (
    localStorage.getItem("tokens") !== null &&
    localStorage.getItem("tokens") !== undefined
  )
    console.log(
      "Tokens from local Storage is : ",
      JSON.parse(localStorage.getItem("tokens"))
    );
  // const authState = useSelector((state) => state.auth);
  // let authToken = authState.token;
  // console.log("AuthToken is : ", authToken);

  // console.log(
  //   "Difference : ",
  //   Date.now() - JSON.parse(localStorage.getItem("tokens")).createdAt
  // );
  //   console.log("Time difference is : ", authToken.token);

  // const token = JSON.parse(localStorage.getItem("token"));
  // console.log("Token is : ", token.createdAt);

  // if (token && token !== undefined && Date.now() - token.createdAt <= 180000) {
  //   console.log(
  //     "Inside app && Token created time is : ",
  //     Date.now() - token.createdAt
  //   );
  // }

  return (
    <div className="min-w-[100vw] min-h-[100vh] bg-gray-900 overflow-auto">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <UserDashboard />
            </PrivateRoute>
          }
        />

        <Route
          path="/generate-image"
          element={
            <PrivateRoute>
              <GenerateImage />
            </PrivateRoute>
          }
        />

        <Route
          path="/likes"
          element={
            <PrivateRoute>
              <LikesOfParticularBlog />
            </PrivateRoute>
          }
        />

        <Route
          path="/particular-blog"
          element={
            <PrivateRoute>
              <ParticularBlog />
            </PrivateRoute>
          }
        />

        <Route
          path="/add-comment"
          element={
            <PrivateRoute>
              <AddComment />
            </PrivateRoute>
          }
        />

        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/varify-email"
          element={
            <SignupRoute>
              <VarifyEmail />
            </SignupRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
