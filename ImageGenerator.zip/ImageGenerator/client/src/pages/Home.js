import React from "react";
import { NavLink } from "react-router-dom";

import Button from "../components/common/Button";
import Navbar from "../components/common/Navbar";

const Home = () => {
  return (
    <div className="min-w-[100%] min-h-[100%] bg-gray-900">
      <Navbar />
      <div className="w-full h-full mt-14 flex flex-col items-center justify-center gap-6">
        <div className="text-blue-600 text-3xl font-bold pt-8">BLOGG APP</div>
        <div className="w-[40%] text-gray-400 mx-auto flex items-center justify-center flex-wrap">
          <div>
            This a blog app where you can generate image by prompt and post
          </div>
          <div>and also can like and comment on others post.</div>
        </div>
        <NavLink to={"/signup"} className="mt-8">
          <Button title={"Get Started"} bgColor={"yellow"} />
        </NavLink>
      </div>
    </div>
  );
};

export default Home;
