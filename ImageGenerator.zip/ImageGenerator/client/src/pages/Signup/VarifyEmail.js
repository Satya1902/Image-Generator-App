import React, { useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";

import { otpGenerator } from "../../utils/helper";
import signupImage from "../../assests/images/signupImage.png";
import { resetSignup, setOtp } from "../../store/signup";
import Navbar from "../../components/common/Navbar";
const VarifyEmail = () => {
  const [localOtp, setLocalOtp] = useState({
    otp: "",
  });

  const signupState = useSelector((state) => state.signup);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // console.log("sgnupDataStore from signupState is : ", signupState.signupData);
  // console.log("otp from signupState is : ", signupState.otp);

  async function changeSingupData(event) {
    setLocalOtp((prev) => {
      return { ...prev, [event.target.name]: event.target.value };
    });
  }

  async function submitForm(event) {
    event.preventDefault();
    const tempOtp = localOtp.otp;
    const signupData = signupState.signupData;
    const otp = signupState.otp;

    if (!tempOtp) {
      toast.error("All fields are mandatory !!!!");
      return;
    }

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/varify-email", {
          tempOtp,
          signupData,
          otp,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (!response) {
        toast.error("Something went wrong. Please try again");
        navigate("/varify-email");
      }

      console.log("Response from backend is : ", response);

      if (response?.data?.success) {
        toast.success("Email has been varified successfully!!!!");
        dispatch(resetSignup());
        navigate("/login");
        return;
      }
      toast.error(response.data.message);
      navigate("/varify-email");
    } catch (error) {
      console.error("Error while varifying email :", error);
      toast.error(
        "Something went wrong while varifying your email Please try again"
      );
    }
  }

  async function resendOTP(event) {
    event.preventDefault();

    let response;
    const email = signupState.signupData.email;
    const otp = otpGenerator();
    dispatch(setOtp(otp));
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/send-otp", { email, otp })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (!response) {
        toast.error(
          "Something went wrong while resending otp. Please try again"
        );
        navigate("/varify-email");
      }

      console.log("Response from backend is : ", response);

      if (response?.data?.success) {
        toast.success(
          "OTP has been sent successfully to your registered email !!!!"
        );
        // navigate("/varify-email");
      }

      if (!response?.data?.success) {
        toast.error(response.data.message);
        navigate("/varify-email");
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      toast.error("Something went wrong while signup please try again !!!!");
      navigate("/varify-email");
    }
  }

  return (
    <div className="max-w-[100vw] min-h-[100%]">
      <Navbar />
      <div className="w-[95%] mx-auto flex flex-wrap gap-5 justify-center mt-14">
        <div className="w-[45%] flex flex-col items-center gap-4">
          <div className="text-blue-600 text-3xl font-bold">Varify Email</div>
          <div className="text-gray-300">
            Enter the otp that has been sent yoir email to vaify your email
            account !!!!
          </div>
          {/* form field  */}
          <form className="w-full mt-4 flex flex-col gap-4">
            {/* OTP field */}
            <div className="w-full flex justify-between gap-1">
              <div className="w-[95%] flex flex-col gap-1">
                <div className="w-full text-gray-400">OTP</div>
                <input
                  type="text"
                  name="otp"
                  value={localOtp.otp}
                  onChange={changeSingupData}
                  placeholder="Enter the otp here"
                  className="w-full rounded-md pl-2"
                />
              </div>
            </div>
            {/* Bttons submit dashboard login  */}
            <div className="text-yellow-400 text-sm mt-2">
              After varifying your email your account will be created with given
              email id and password
            </div>
            {/* Buttons of signup varify-email and resebdOTP  */}
            <div className="flex mt-4 justify-center items-center gap-10 mt-16">
              <NavLink to={"/signup"}>
                <button className="text-white bg-blue-400 font-bold px-3 py-2 rounded-md">
                  Back to Signup
                </button>
              </NavLink>
              <button
                className="text-white bg-yellow-400 font-bold px-3 py-2 rounded-md"
                onClick={submitForm}
              >
                Varify Email
              </button>
              <button
                className="text-white bg-blue-600 font-bold px-3 py-2 rounded-md"
                onClick={resendOTP}
              >
                ResendOTP
              </button>
            </div>
          </form>
        </div>
        {/* Signup image  */}
        <div className="sm:w-[45%] min-w-[45%]">
          <img
            src={signupImage}
            alt="Signupimage"
            className="w-full h-full rounded-md"
          />
        </div>
      </div>
    </div>
  );
};

export default VarifyEmail;
