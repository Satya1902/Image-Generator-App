import { useSelector } from "react-redux";
import Navbar from "../../components/common/Navbar";
import { useEffect, useState } from "react";
import axios from "axios";

const ParticularBlog = () => {
  const [user, setUser] = useState(null);

  const authState = useSelector((state) => state.auth);
  const token = authState.token;

  const postState = useSelector((state) => state.post);
  const singlePost = postState.singlePost;
  console.log("single Post is : ", singlePost);

  async function fetchUser() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/fetch-user", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        setUser(response.data.user);
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setUser(null);
    }
  }

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <div className="w-[100vw] h-[100vh] overflow-hidden">
      <Navbar user={user} className="h-[10%]" />
      <div className="h-[80%] flex flex-col gap-8 mt-12 border-2">
        <div className="">
          <img
            src={singlePost.image}
            alt="image1"
            className="w-[70%] h-[50%] object-contain"
          />
        </div>
      </div>
    </div>
  );
};

export default ParticularBlog;
