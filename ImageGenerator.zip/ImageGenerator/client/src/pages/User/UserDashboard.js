import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { RxDoubleArrowLeft } from "react-icons/rx";
import { RxDoubleArrowRight } from "react-icons/rx";
import { BiSolidLike } from "react-icons/bi";
import { FaComment } from "react-icons/fa";
import toast from "react-hot-toast";

import Navbar from "../../components/common/Navbar";
import { NavLink, useNavigate } from "react-router-dom";
import { setYourBlogs } from "../../store/yourBlogs";
import { setLikes, setSinglePost } from "../../store/post";
// import { set } from "../../../../server/services/MailSenderTransporter";
// import Button from "../../components/common/Button";

const UserDashboard = () => {
  const [user, setUser] = useState(null);
  const [openProfileSlide, setOpenProfileSlide] = useState(true);
  const [allBlogs, setAllBlogs] = useState(null);
  const [tempYourBlog, setTempYourBlogs] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 2;
  const [blogType, setBlogType] = useState("allBlogs");
  const [isLiked, setIsLiked] = useState(false);
  // const [likes, setLikes] = useState();

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const authState = useSelector((state) => state.auth);
  const token = authState.token;

  const blogState = useSelector((state) => state.blog);
  const tempYourBlogs = blogState.yourBlogs;
  // const location = useLocation();

  const postState = useSelector((state) => state.post);
  const likes = postState.likes;

  // console.log("Likes of particular blog are : ", likes);

  if (user) {
    console.log("Details of user is ", user);
  }

  if (tempYourBlogs) console.log("Your blogs from store : ", tempYourBlogs);
  console.log("Blog type is : ", blogType);

  let totalPages = 0;
  if (allBlogs && allBlogs.length > 0)
    totalPages = Math.ceil(allBlogs.length / itemsPerPage);

  let currentBlogs;
  if (allBlogs && blogType === "allBlogs") {
    console.log("allBlogs", allBlogs);
    currentBlogs = allBlogs.slice(
      (currentPage - 1) * itemsPerPage,
      currentPage * itemsPerPage
    );
    console.log("current blogs are : ", currentBlogs);
  } else if (tempYourBlog && blogType === "yourBlogs") {
    currentBlogs = tempYourBlog.slice(
      (currentPage - 1) * itemsPerPage,
      currentPage * itemsPerPage
    );

    console.log("Your current blogs are : ", currentBlogs);
  }

  // Handle page navigation
  const goToPage = (page) => setCurrentPage(page);

  async function fetchUser() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/fetch-user", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        setUser(response.data.user);
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setUser(null);
    }
  }

  // To fetch all blogs
  async function fetchAllBlogs() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/allblogs", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        setAllBlogs(response.data.allBlogs);
        console.log("All blogs are : ", response.data.allBlogs);
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setAllBlogs(null);
    }
  }

  // function setIsLikedFunction() {}

  useEffect(() => {
    fetchUser();
    fetchAllBlogs();
  }, []);

  // To Fetch all blogs that are created by you
  async function fetchYourBlogs() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/yourblogs", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      // console.log(
      //   "Response from backend while fetching your blogs : ",
      //   response
      // );

      if (response?.data?.success) {
        const yourBlogData = response.data.yourBlogs;
        setTempYourBlogs(yourBlogData);
        console.log("Your blog data is ", yourBlogData);
        dispatch(setYourBlogs(yourBlogData));
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setUser(null);
    }
  }

  function yourBlogHandler() {
    fetchYourBlogs();
    // console.log("Your Blogs are : ", yourBlogs);
    // console.log("Your blogs from store : ", tempYourBlogs);
    // setAllBlogs(null);
  }

  async function likeHnadler(blog) {
    console.log("Inside Like Handler ");
    console.log("blog : ", blog);

    if (!token) {
      return;
    }

    setIsLiked(true);

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/create-like", {
          token,
          blog,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      console.log(
        "Response from backend while liking the blog is : ",
        response
      );

      if (response?.data?.success) {
        console.log("You have liked this post successfully : ");
        toast.success("You have liked this blog successfully");
      }
    } catch (error) {
      console.error("You have already liked this post");
    }
  }

  async function DislikeHnadler(blog) {
    console.log("Inside dislike handler ");

    if (!token) {
      return;
    }

    setIsLiked(false);

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/dislike", {
          token,
          blog,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      console.log(
        "Response from backend while liking the blog is : ",
        response
      );

      if (response?.data?.success) {
        console.log("You have disliked this post successfully : ");
        toast.error("You have disliked this blog successfully");
      }
    } catch (error) {
      console.error("You have already disliked this post");
    }
  }

  // function showAllLikes(event) {
  //   event.preventDefault();
  //   console.log("Inside show all Likes");
  // }

  function blogHandler(blog) {
    dispatch(setSinglePost(blog));
    // event.preventDfault();
    console.log("Inside blog handler and blog is ", blog);
    navigate("/particular-blog");
  }

  return (
    <div className="w-[100vw] h-[100vh] overflow-hidden">
      {/* Navbar  */}
      <Navbar user={user} />
      {/* User Dashboard  */}
      <div className="min-w-[100vw] min-h-[100vh] flex">
        {/* User sliding profile  */}
        {openProfileSlide && (
          <div className="w-[25%] h-[92vh] flex flex-col items-center justify-center bg-gray-700 gap-8">
            <button className="w-[90%] bg-green-400 border-b-[1px] px-2 py-1 text-white mx-auto rounded-md">
              Your Profile
            </button>
            <button className="w-[90%] bg-blue-400 border-b-[1px] px-2 py-1 text-white mx-auto rounded-md">
              Update Your Profile
            </button>
            <button className="w-[90%] border-b-[1px] px-2 py-1 text-white mx-auto rounded-md">
              Change Your Password
            </button>
            <button className="w-[90%] px-2 py-1 bg-red-500 text-black mx-auto rounded-md">
              Delete Your Account
            </button>
            <button className="w-[90%] bg-blue-200 border-b-[1px] px-2 py-1 text-black mx-auto rounded-md">
              Settings
            </button>
            <button className="w-[90%] bg-red-400 border-[1px] px-2 py-1 text-white mx-auto rounded-md">
              Logout
            </button>
          </div>
        )}

        {/* Actual user Dashboard  */}
        <div className="w-full h-full flex flex-col mt-8">
          {/* Buttons to handle information about blogs */}
          <div className="w-full flex items-center text-lg text-blue-600">
            {/* Icon to slide profile  */}
            <button
              className={`w-[8%] py-[-1] text-gray-400`}
              onClick={() => {
                setOpenProfileSlide(!openProfileSlide);
              }}
            >
              {openProfileSlide ? (
                <RxDoubleArrowLeft />
              ) : (
                <RxDoubleArrowRight />
              )}
            </button>
            {/* Buttons to show posts  */}
            <div className="w-full flex justify-evenly">
              <button
                className={`text-lg text-blue-600 rounded-md px-2 hover:bg-gray-300 hover:scale-110 transition-all duration-300 hover:shadow-md hover:shadow-white ${
                  blogType === "allBlogs"
                    ? " border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
                onClick={() => {
                  setBlogType("allBlogs");
                }}
              >
                All blogs
              </button>
              <button
                className={`text-blue-600 font-bold rounded-md px-2 hover:bg-gray-300 hover:scale-110 transition-all duration-300 hover:shadow-md hover:shadow-white ${
                  blogType === `yourBlogs`
                    ? " border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
                onClick={() => {
                  yourBlogHandler();
                  setBlogType("yourBlogs");
                }}
              >
                {" "}
                Your Blogs
              </button>
            </div>
          </div>
          {/* Original images and Pagination*/}
          {!currentBlogs ? (
            <div className="w-full h-full flex items-center justify-center mt-14">
              No Blogs yet !!!
            </div>
          ) : (
            <div className="w-full h-[84vh] flex flex-col justify-between overflow-hidden">
              {/* To show all blogs, likes and comments */}
              <div className="w-full h-[80%] flex items-center justify-center gap-4 mt-4">
                {currentBlogs.map((blog, index) => (
                  <div className="w-[45%] h-[100%]" key={index}>
                    {/* Images  */}
                    {blog.image && (
                      <div
                        onClick={() => {
                          blogHandler(blog);
                        }}
                        className="w-full h-full flex flex-col hover:scale-110 transition-all duration-300 bg-gray-800"
                      >
                        <img
                          src={blog.image}
                          alt="blogImage"
                          className="w-full h-[90%] object-fill"
                        />
                        {/* Icons to Like and comments  */}
                        <div className="w-full flex justify-between items-center">
                          {/* Like button  */}
                          <div className="ml-2 text-blue-600 mt-1 flex items-center justify-between gap-2">
                            {blog?.likes && blog.likes.includes(user._id) && (
                              <button
                                onClick={(event) => {
                                  event.stopPropagation();
                                  DislikeHnadler(blog);
                                }}
                              >
                                <BiSolidLike className=" text-xl" />
                              </button>
                            )}
                            {(blog?.likes?.length === 0 ||
                              !blog.likes.includes(user._id)) && (
                              <button
                                onClick={(event) => {
                                  event.stopPropagation();
                                  likeHnadler(blog);
                                }}
                                className="text-white"
                              >
                                <BiSolidLike className=" text-xl" />
                              </button>
                            )}
                            <NavLink
                              to={"/likes"}
                              className="border-b-[1px] border-b-blue-600"
                              onClick={(event) => {
                                event.stopPropagation();
                                dispatch(setLikes(blog.likes));
                                // console.log(
                                //   "Likes of the particular blog are : ",
                                //   blog.likes
                                // );
                              }}
                            >
                              {blog?.likes.length}
                            </NavLink>
                          </div>
                          {/* view this blog button  */}
                          <button
                            onClick={(event) => {
                              event.stopPropagation();
                              blogHandler(blog);
                            }}
                            className="rounded-md border-[1px] px-1 text-black mt-2 bg-yellow-200 font-bold"
                          >
                            View this blog
                          </button>
                          {/* count of Comments  */}
                          <div className="mr-2 text-green-600 mt-1 flex items-center justify-between gap-2">
                            <NavLink
                              to="/add-comment"
                              onClick={(event) => {
                                // navigate("/add-comment");
                                event.stopPropagation();
                              }}
                            >
                              <FaComment className="text-xl " />
                            </NavLink>
                            <NavLink
                              to="/all-comments"
                              onClick={(event) => {
                                // navigate("/all-comment");
                                event.stopPropagation();
                              }}
                            >
                              <div>{blog.comments.length}</div>
                            </NavLink>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {/* <div className="w-full h-full flex justify-center items-center space-x-2 text-white pb-2 border-2">
                Hello
              </div> */}
              {/* To handle pagination  */}
              <div className="w-full flex justify-center items-center space-x-2 text-black font-bold pb-2 mb-8">
                <button
                  className={`px-3 py-1 rounded ${
                    currentPage === 1
                      ? "bg-gray-300 cursor-not-allowed"
                      : "bg-blue-500 hover:bg-blue-600 text-white"
                  }`}
                  onClick={() => goToPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                {[...Array(totalPages)].map((_, i) => (
                  <button
                    key={i}
                    className={`px-3 py-1 rounded ${
                      currentPage === i + 1
                        ? "bg-blue-500 text-white"
                        : "bg-gray-200 hover:bg-gray-300"
                    }`}
                    onClick={() => goToPage(i + 1)}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  className={`px-3 py-1 rounded ${
                    currentPage === totalPages
                      ? "bg-gray-300 cursor-not-allowed"
                      : "bg-blue-500 hover:bg-blue-600 text-white"
                  }`}
                  onClick={() => goToPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
