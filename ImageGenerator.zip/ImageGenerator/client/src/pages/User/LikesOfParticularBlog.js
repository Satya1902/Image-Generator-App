import { useSelector } from "react-redux";
import Navbar from "../../components/common/Navbar";
import { useEffect, useState } from "react";
import axios from "axios";

const LikesOfParticularBlog = () => {
  const [user, setUser] = useState(null);

  const authState = useSelector((state) => state.auth);
  const token = authState.token;

  const postState = useSelector((state) => state.post);
  const likes = postState.likes;
  console.log("Likes are ", likes);

  async function fetchUser() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/fetch-user", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        setUser(response.data.user);
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setUser(null);
    }
  }

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <div className="w-[100vw] h-[100vh] overflow-hidden">
      <Navbar user={user} />
      <div className="flex flex-col gap-8 mt-12">
        <div className="text-white text-3xl font-bold mx-auto flex gap-2 p-2 ">
          Total likes of this blog is ~{" "}
          <div className="text-blue-400">{likes.length}</div>
        </div>
        <div className="flex flex-col gap-2 mx-auto mt-10">
          {likes.map((like, index) => (
            <div className="text-green-400 " key={index}>
              {like}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LikesOfParticularBlog;
