import React, { useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { useDispatch } from "react-redux";

import loginImage from "../assests/images/signupImage.png";
import { resetAuth, setToken } from "../store/auth";
import Navbar from "../components/common/Navbar";

const Login = () => {
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  // const authState = useSelector((state) => state.auth);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // console.log("Token from auth state is ", authState.token);
  // console.log(
  //   "Token from localStorage is ",
  //   JSON.parse(localStorage.getItem("token"))
  // );

  async function changeSingupData(event) {
    setLoginData((prev) => {
      return { ...prev, [event.target.name]: event.target.value };
    });
  }

  async function submitForm(event) {
    event.preventDefault();

    const { email, password } = loginData;

    if (!email || !password) {
      toast.error("Please fill all fields as all fields are mandatory ");
    }

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/login", {
          email,
          password,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (!response) {
        toast.error("Something went wrong. Please try again");
        navigate("/login");
      }

      console.log("Response from backend is : ", response);

      if (response?.data?.success) {
        toast.success("Logged in successfully  !!!!");
        const tokens = { token: response?.data?.token, createdAt: Date.now() };
        dispatch(setToken(tokens));
        navigate("/dashboard");
        return;
      }
      toast.error(response.data.message);
      navigate("/login");
    } catch (error) {
      console.error("Error while login :", error);
      toast.error("Something went wrong while login Please try again");
      dispatch(resetAuth());
    }
  }

  async function forgotPassword(event) {
    event.preventDefault();
    toast.success("Inside forgot password");
  }

  return (
    <div className="max-w-[100vw] min-h-[100%]">
      <Navbar />
      <div className="w-[95%] mx-auto flex flex-wrap gap-5 justify-center mt-14">
        <div className="w-[45%] flex flex-col items-center gap-4">
          <div className="text-blue-600 text-3xl font-bold">Login Page</div>
          <div className="text-gray-300">
            Please enter your registered email and password to create and post
            blog !!!!
          </div>
          {/* form field  */}
          <form className="w-full mt-4 flex flex-col gap-4">
            {/* Email field */}
            <div className="w-full flex justify-between gap-1">
              <div className="w-[95%] flex flex-col gap-1">
                <div className="w-full text-gray-400">user name</div>
                <input
                  type="email"
                  name="email"
                  value={loginData.email}
                  onChange={changeSingupData}
                  placeholder="Enter your email here"
                  className="w-full rounded-md pl-2"
                />
              </div>
            </div>
            {/* Password field */}
            <div className="w-full flex justify-between gap-1">
              <div className="w-[95%] flex flex-col gap-1">
                <div className="w-full text-gray-400">Password</div>
                <input
                  type="password"
                  name="password"
                  value={loginData.password}
                  onChange={changeSingupData}
                  placeholder="Enter your password here"
                  className="w-full rounded-md pl-2"
                />
              </div>
            </div>
            {/* Bttons submit dashboard login  */}
            <div className="text-yellow-400 text-sm mt-2">
              After login you will be able to generate image via prompt and also
              you can post that image. You can likes other's post and also you
              an comment on that
            </div>
            {/* Buttons of signup Login and forgotPassword  */}
            <div className="flex mt-4 justify-center items-center gap-10 mt-16">
              <NavLink to={"/signup"}>
                <button className="text-white bg-blue-400 font-bold px-3 py-2 rounded-md">
                  Back to Signup
                </button>
              </NavLink>
              <button
                className="text-white bg-yellow-400 font-bold px-3 py-2 rounded-md"
                onClick={submitForm}
              >
                Login
              </button>
              <button
                className="text-white bg-blue-600 font-bold px-3 py-2 rounded-md"
                onClick={forgotPassword}
              >
                Forgot Password
              </button>
            </div>
          </form>
        </div>
        {/* Signup image  */}
        <div className="sm:w-[45%] min-w-[45%]">
          <img
            src={loginImage}
            alt="Signupimage"
            className="w-full h-full rounded-md"
          />
        </div>
      </div>
    </div>
  );
};

export default Login;
