const express = require("express");

const { getAllPost } = require("../../controllers/OtherC/Posts");
const { createPost } = require("../../controllers/OtherC/Posts");

const router = express.Router();

router.post("/createpost", createPost);
router.get("/", getAllPost);

module.exports = router;
