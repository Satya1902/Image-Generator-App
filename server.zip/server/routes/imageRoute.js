const express = require("express");
const multer = require("multer");

// const UploadImageToCludinary = require("../controllers/user/UploadImageToCloudinary");
const { Auth } = require("../middlewares/Auth");
const GenerateAIImage = require("../controllers/image/GenerateAIImage");
const DownloadImage = require("../controllers/image/DownloadImage");
const UploadLocalImageToCloudinary = require("../controllers/image/UploadLocalImageToCloudinary");

// const UploadImageToCludinary = require("../controllers/user/UploadImageToCloudinary");
const saveImage = require("../controllers/image/SaveImage");

const router = express.Router();

const storage = multer.memoryStorage(); // Temporarily store the file in memory
const upload = multer({ storage });

// To generate images based on provided prompt
router.post("/generate-image", GenerateAIImage);
// To download the particulare image provided for the frontend user
router.post("/download-image", Auth, DownloadImage);
// To save the local image to cloudinary
router.post("/save-image-to-cloudinary", UploadLocalImageToCloudinary);

// Endpoint to upload an image retrieved from frontend without saving that to local machine to cloudinary
// router.post("/upload", upload.single("image"), UploadImageToCludinary);

// Endpoint to save an image to cloudinary along with savedImages model
router.post("/save-image", Auth, saveImage);

module.exports = router;
