const dotenv = require("dotenv");
const axios = require("axios");
// const { json } = require("express");

dotenv.config();

// Controller to generate Image using API from unsplashed App
const GenerateAIImage = async (req, res) => {
  try {
    const { prompt } = req.body || req.query;

    console.log("prompt", prompt);

    const apiKey = process.env.UNSPLASH_ACCESS_KEY;
    const url = `https://api.unsplash.com/search/photos?query=${prompt}&client_id=${apiKey}`;

    const response = await axios.get(url);
    const imageUrls = response.data.results;
    console.log("Response from unsplashed api is : ", imageUrls);

    const images = [];

    imageUrls.map((imageUrl) => {
      images.push(imageUrl.urls.regular);
    });

    console.log("images : ", images);

    return res.status(200).json({
      success: true,
      message: "Image has been generated successfully using unsplashed app",
      images: images,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: false,
      message:
        "Internal server error, Something went wrong while generating image from UnSplashedApp",
    });
  }
};

module.exports = GenerateAIImage;
