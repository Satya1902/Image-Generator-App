const dotenv = require("dotenv");
const { v2: cloudinary } = require("cloudinary");

// const { CloudinaryStorage } = require("multer-storage-cloudinary");

const Posts = require("../../models/Posts");
dotenv.config();

const getAllPost = async (req, res, next) => {
  try {
    const posts = await Posts.find({});
    return res.status(200).json({
      succss: true,
      message: "Posts has been fetched successfully",
      data: posts,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: true,
      message:
        "Internal server error, Something went wrong while fetching posts from backend",
    });
  }
};

async function createPost(req, res, next) {
  try {
    const { name, prompt, photo } = req.body;
    const photoUrl = await cloudinary.uploader.upload(photo);
    const newPost = await Posts.create({
      name,
      prompt,
      photo: photoUrl?.secure_url,
    });

    return res.status(200).json({
      succss: true,
      message: "Posts has been created successfully",
      data: newPost,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: true,
      message:
        "Internal server error, Something went wrong while creating post",
    });
  }
}

module.exports = { getAllPost, createPost };
