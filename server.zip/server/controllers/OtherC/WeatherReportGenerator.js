const dotenv = require("dotenv");
const axios = require("axios");
const { json } = require("express");

dotenv.config();

// Controller to generate Image
const WeatherReportGenerator = async (req, res) => {
  try {
    const { city } = req.body;

    const apiKey = process.env.WEATHER_API_KEY;
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    const response = await axios.get(url);
    console.log("Response from OpenWeatherApp api is : ", response.data);

    return res.status(200).json({
      success: true,
      message: "Weather Report has been generated successfully ",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: false,
      message:
        "Internal server error, Something went wrong while generating weather report from OpenWeatherApp",
    });
  }
};

module.exports = WeatherReportGenerator;
