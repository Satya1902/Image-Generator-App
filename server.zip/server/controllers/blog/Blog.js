const dotenv = require("dotenv");
const UserModel = require("../../models/UserModel");
const BlogModel = require("../../models/BlogModel");
const { BiHeading } = require("react-icons/bi");

dotenv.config();

// Controller to generate Image using API from unsplashed App
const createBlog = async (req, res) => {
  try {
    const { imageUrl, user, prompt, blog_heading, blog_body } = req.body;

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Please share user ",
      });
    }

    // console.log(
    //   "user prompt imageUrl heading body",
    //   user,
    //   prompt,
    //   imageUrl,
    //   blog_heading,
    //   blog_body
    // );

    const userId = user.id;
    const userObject = await UserModel.findById(userId);
    userObject.password = undefined;

    console.log("User Object is : ", userObject);

    const blog = new BlogModel();
    blog.user = userObject;

    if (imageUrl) {
      blog.image = imageUrl;
      blog.prompt = prompt;
    } else if (heading && body) {
      blog.heading = heading;
      blog.body = body;
    }

    console.log("Blog is : ", blog);

    await blog.save();

    const updateduser = await UserModel.findByIdAndUpdate(
      { _id: userId },
      { $push: { blogs: blog } }
    );

    return res.status(200).json({
      success: true,
      message: "Blog has been created successfully !!!!",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: false,
      message:
        "Internal server error, Something went wrong while creating blog",
    });
  }
};

// To fetch all blogs
async function fetchAllBlogs(req, res) {
  try {
    const allBlogs = await BlogModel.find({}).populate("user");

    // console.log("all blogs are : ", allBlogs);

    return res.status(200).json({
      success: true,
      message: "All blogs have been fetched successfully !!!!!",
      allBlogs,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: false,
      message:
        "Internal server error, Something went wrong while fetching all blogs",
    });
  }
}

module.exports = { createBlog, fetchAllBlogs };
