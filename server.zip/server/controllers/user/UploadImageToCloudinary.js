const { v2: cloudinary } = require("cloudinary");

async function UploadImageToCludinary(req, res, next) {
  try {
    const fileBuffer = req.file.buffer; // Access file buffer
    const { email, otp } = req.body;

    // console.log(
    //   "Inside upload and email,otp and file buffer are : ",
    //   email,
    //   otp,
    //   fileBuffer
    // );

    if (fileBuffer) {
      console.log("File Buffer is : ", fileBuffer);
    }

    let imageUrl;

    // Create an upload stream
    const uploadStream = cloudinary.uploader.upload_stream(
      { folder: "blogapp" },
      (error, result) => {
        if (error) {
          console.error("Upload to Cloudinary failed:", error);
          return res.status(500).json({
            success: false,
            message: "Iternal server error while uploadin image to cloudinary",
          });
        }

        console.log("Uploaded file URL:", result.secure_url);
        imageUrl = result.secure_url;
        // Clear buffer reference after upload
        req.file.buffer = null;
      }
    );

    // Pipe the buffer into the Cloudinary upload stream
    const stream = require("stream");
    const readableStream = new stream.PassThrough();
    readableStream.end(fileBuffer);
    readableStream.pipe(uploadStream);

    // Clear buffer reference after piping
    req.file.buffer = null;

    // req.body = { email, otp, imageUrl };
    // next();

    return res.status(200).json({
      success: true,
      message: "Image has been uploaded to cloudinary successfully !!!!!",
      imageUrl,
    });
  } catch (error) {
    console.error("Error during upload:", error);
    return res.status(500).json({
      success: false,
      message: "Iternal server error while uploadin image to cloudinary",
    });
  }
}

module.exports = UploadImageToCludinary;
