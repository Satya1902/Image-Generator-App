const dotenv = require("dotenv");
const bcrypt = require("bcryptjs");

const transporter = require("../../services/MailSenderTransporter");
const OtpModel = require("../../models/OTPModel");
const UserModel = require("../../models/UserModel");
const OTPModel = require("../../models/OTPModel");

async function CreateUser(req, res) {
  try {
    const { signupData } = req.body;
    const email = signupData.email;

    if (!signupData) {
      return res.status(400).json({
        success: false,
        message: " please share email and signupData ",
      });
    }

    // Existing user
    const existingUser = await UserModel.findOne({ email: signupData.email });

    if (existingUser) {
      return res.status(401).json({
        success: false,
        message:
          "Your account is already exist with given email , Please login to create and post blog ",
      });
    }

    // Create user

    const newUser = new UserModel({});
    let hashedPassword = await bcrypt.hash(signupData.password, 10);

    newUser.firstname = signupData.firstname;
    newUser.lastname = signupData.lastname;
    newUser.email = signupData.email;
    newUser.role = "USER";
    newUser.password = hashedPassword;

    const user = await newUser.save();
    console.log("User is : ", user);

    //  Send mail to user that his account has been created successflly

    let info = await transporter.sendMail({
      from: "er.satyagautam@gmail.com",
      to: email,
      subject: "BLOG APP",
      html: `<div> <h1>This email is to varify that your account has been created succefully with below details !!!!</h1>
      <br/><p1>username : ${signupData.email}</p1><br/>
      <p1>firstname : ${signupData.firstname}</p1><br/>
      <p1>lastname : ${signupData.lastname}</p1><br/>
      <p1>password : ${signupData.password}</p1><br/>
      </div>`,
    });

    return res.status(200).json({
      success: true,
      message:
        " Your Email has been vaified and also account has been created sccessfully ",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message:
        "Internal server error , Something went wrong while creating account ",
    });
  }
}

async function fetchUser(req, res) {
  try {
    const userId = req.body.user.id;

    // console.log("Inside fetchUser and userid is : ", userId);

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: " please share user payload ",
      });
    }

    // Fetch user
    const existingUser = await UserModel.findById({ _id: userId });

    if (!existingUser) {
      return res.status(404).json({
        success: false,
        message: "No user found with the shared user id ",
      });
    }
    existingUser.password = undefined;
    return res.status(200).json({
      success: true,
      message: " User fetched successfully ",
      user: existingUser,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message:
        "Internal server error , Something went wrong while fetching user ",
    });
  }
}

module.exports = { CreateUser, fetchUser };
