const BlogModel = require("../../models/BlogModel");
const UserModel = require("../../models/UserModel");

async function fetchYourBlogs(req, res) {
  try {
    const userId = req.body.user.id;

    // console.log("Inside fetchUser and userid is : ", userId);

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: " please share user payload ",
      });
    }

    // Fetch user
    const existingUser = await UserModel.findById({ _id: userId });

    if (!existingUser) {
      return res.status(404).json({
        success: false,
        message: "No user found with the shared user id ",
      });
    }

    // existingUser.password = undefined;

    // To Fetch your blogs
    const yourBlogs = await BlogModel.find({ user: userId });

    return res.status(200).json({
      success: true,
      message: " User fetched successfully ",
      yourBlogs,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message:
        "Internal server error , Something went wrong while fetching user ",
    });
  }
}

module.exports = fetchYourBlogs;
