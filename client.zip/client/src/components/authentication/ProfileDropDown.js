import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink, useNavigate } from "react-router-dom";
import { resetAuth } from "../../store/auth";

const ProfileDropDown = ({ user }) => {
  const [isOpen, setIsOpen] = useState(false);

  const dropdownRef = useRef(null);
  const authState = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  console.log("Token from auth is : ", authState.token);

  user.firstname =
    String(user.firstname).charAt(0).toUpperCase() +
    String(user.firstname).slice(1);
  user.lastname =
    String(user.lastname).charAt(0).toUpperCase() +
    String(user.lastname).slice(1);

  // Toggle dropdown visibility
  const toggleDropdown = () => setIsOpen(!isOpen);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  function logoutHandler(event) {
    event.preventDefault();
    console.log("Hello");
    dispatch(resetAuth());
    navigate("/login");
  }

  return (
    <div className="relative " ref={dropdownRef}>
      {/* Profile button */}
      <button
        onClick={toggleDropdown}
        className="flex items-center py-2 px-3 rounded-full bg-gray-200 hover:bg-gray-300"
      >
        <div className="flex justify-between gap-1">
          {user?.pprofileImage && (
            <img
              src={user.profileImage}
              alt="Profile"
              className="w-8 h-8 rounded-full"
            />
          )}
          {!user.profileImage && (
            <span className="flex text-gray-900 font-bold gap-1">
              <div>{user.firstname}</div>
              <div>{user.lastname}</div>
            </span>
          )}
          {/* <span className="ml-2 font-medium text-gray-900">Profile</span> */}
        </div>
      </button>

      {/* Dropdown menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white border rounded-md shadow-lg">
          <NavLink
            to="/user-profile"
            className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
          >
            My Profile
          </NavLink>
          <NavLink
            to="/user-setting"
            className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
          >
            Setting
          </NavLink>
          <button
            className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
            onClick={logoutHandler}
          >
            Logout
          </button>
        </div>
      )}
    </div>
  );
};

export default ProfileDropDown;
