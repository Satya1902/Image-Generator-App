import React from "react";
import toast from "react-hot-toast";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

const SignupRoute = ({ children }) => {
  const signupState = useSelector((state) => state.signup);
  const signupDataStore = signupState.signupDataStore;
  if (signupDataStore !== null) return children;
  else {
    toast.error(" You do not have permission for this page ");
    return <Navigate to="/Signup" />;
  }
};

export default SignupRoute;
