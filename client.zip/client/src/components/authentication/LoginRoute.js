import React from "react";
import toast from "react-hot-toast";
import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

const LoginRoute = ({ children }) => {
  const authState = useSelector((state) => state.auth);
  const token = authState.token;
  if (token !== null && token !== undefined) return children;
  else {
    toast.error(" Please login ");
    return <Navigate to="/login" />;
  }
};

export default LoginRoute;
