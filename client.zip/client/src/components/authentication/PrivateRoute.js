import React from "react";
// import toast from "react-hot-toast";
import { useSelector } from "react-redux";

import Home from "../../pages/Home";

const PrivateRoute = ({ children }) => {
  const authState = useSelector((state) => state.auth);
  const token = authState.token;

  if (token && token !== undefined) {
    return children;
  } else return <Home />;
};

export default PrivateRoute;
