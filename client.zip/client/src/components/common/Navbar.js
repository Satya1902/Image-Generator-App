import React, { useEffect, useRef, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";

import logo from "../../assests/images/logo.png";
// import ProfileDropDown from "../authentication/ProfileDropDown";
import { resetAuth } from "../../store/auth";

const Navbar = ({ user }) => {
  const [isOpen, setIsOpen] = useState(false);

  const dropdownRef = useRef(null);
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  if (user && (user.email === undefined || user.email === null)) {
    user = null;
  } else if (user) {
    user.firstname =
      String(user.firstname).charAt(0).toUpperCase() +
      String(user.firstname).slice(1);
    user.lastname =
      String(user.lastname).charAt(0).toUpperCase() +
      String(user.lastname).slice(1);
  }

  const toggleDropdown = () => setIsOpen(!isOpen);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  function logoutHandler(event) {
    event.preventDefault();
    dispatch(resetAuth());
    navigate("/login");
  }

  return (
    <div className="w-[100vw] bg-gray-800">
      <div className="w-[90%] mx-auto flex p-1 justify-between items-center">
        {/* Logo */}
        <NavLink to={"/"}>
          <img
            alt="logo"
            src={logo}
            className="rounded-full w-[70px] h-[30px] hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200"
          />
        </NavLink>
        {/* (Dashboard and Explore more) // (Generate Image && post blog) */}
        <div className="flex gap-4 items-center justify-center text-gray-300">
          <NavLink to={"/dashboard"}>
            <button
              className={`rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200 ${
                location.pathname === "/" || location.pathname === "/dashboard"
                  ? "text-yellow-400  && border-b-[1px] border-yellow-400"
                  : "text-gray-400"
              }`}
            >
              Dashboard
            </button>
          </NavLink>
          {user && (
            <NavLink to={"/generate-image"}>
              <button
                className={`rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200 ${
                  location.pathname === "/generate-image"
                    ? "text-yellow-400  && border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
              >
                Generate Image
              </button>
            </NavLink>
          )}
          {user && (
            <NavLink to={"/post-blog"}>
              <button className="rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200">
                Post Blog
              </button>
            </NavLink>
          )}
          {!user && (
            <NavLink to={"/signup"}>
              <button className="rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200">
                Explore-more
              </button>
            </NavLink>
          )}
        </div>
        {/* (Login and Signup) /  (Saved Image && Profile DropDown)*/}
        <div className="flex gap-4 items-center justify-center text-gray-300">
          {!user && (
            <NavLink to={"/signup"}>
              <button
                className={`rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200 ${
                  location.pathname === "/signup"
                    ? "text-yellow-400  && border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
              >
                Signup
              </button>
            </NavLink>
          )}
          {!user && (
            <NavLink to={"/login"}>
              <button
                className={`rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200 ${
                  location.pathname === "/login"
                    ? "text-yellow-400  && border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
              >
                Login
              </button>
            </NavLink>
          )}
          {/* Saved Image  */}
          {user && (
            <NavLink to={"/saved-images"}>
              <button
                className={`flex gap-1 rounded-md p-1 hover:text-white hover:scale-110 hover:shadow-sm hover:shadow-white transition-all duration-200 ${
                  location.pathname === "/saved-images"
                    ? "text-yellow-400  && border-b-[1px] border-yellow-400"
                    : "text-gray-400"
                }`}
              >
                Saved images
                <div className="text-blue-600">{user.savedImages.length}</div>
              </button>
            </NavLink>
          )}
          {/* Profile Dropdown  */}
          {user && (
            <div className="relative " ref={dropdownRef}>
              {/* Profile button */}
              <button
                onClick={toggleDropdown}
                className="flex items-center py-2 px-3 rounded-full bg-gray-200 hover:bg-gray-300 hover:bg-gray-300 hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-gray-400"
              >
                {/* Profile image  */}
                <div className="flex justify-between gap-1">
                  {user?.profileImage && (
                    <img
                      src={user.profileImage}
                      alt="Profile"
                      className="w-8 h-8 rounded-full"
                    />
                  )}
                  {!user.profileImage && (
                    <span className="flex text-gray-900 font-bold ">
                      <div>{user.firstname.charAt(0)}</div>
                      <div>{user.lastname.charAt(0)}</div>
                    </span>
                  )}
                  {/* <span className="ml-2 font-medium text-gray-900">Profile</span> */}
                </div>
              </button>

              {/* Dropdown menu */}
              {isOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border rounded-md shadow-lg">
                  <NavLink
                    to="/user-profile"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    My Profile
                  </NavLink>
                  <NavLink
                    to="/user-setting"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    Setting
                  </NavLink>
                  <button
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                    onClick={logoutHandler}
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Navbar;
