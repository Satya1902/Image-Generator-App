import React from "react";

const Button = ({ title, bgColor }) => {
  return (
    <button className={`bg-${bgColor}-400 px-3 py-2 rounded-md font-bold`}>
      {title}
    </button>
  );
};

export default Button;
