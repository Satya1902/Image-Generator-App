import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  likes:
    localStorage.getItem("likes") && localStorage.getItem("likes") !== undefined
      ? JSON.parse(localStorage.getItem("likes")).token
      : null,
};

const blogSlice = createSlice({
  name: "blog",
  initialState: initialState,
  reducers: {
    setLikes: (state, action) => {
      if (action.payload && action.payload !== undefined) {
        localStorage.setItem("likes", JSON.stringify(action.payload));
        state.likes = action.payload.likes;
      }
    },
    removeLikes: (state, action) => {
      localStorage.removeItem("likes");
    },
    resetBlog: (state) => {
      state.likes = null;
      localStorage.removeItem("likes");
    },
  },
});

export const { setLikes, removeLikes, resetBlog } = blogSlice.actions;

export default blogSlice.reducer;
