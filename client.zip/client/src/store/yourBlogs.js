import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  yourBlogs:
    localStorage.getItem("yourBlogs") &&
    localStorage.getItem("yourBlogs") !== undefined
      ? JSON.parse(localStorage.getItem("yourBlogs")).token
      : null,
};

const blogSlice = createSlice({
  name: "blog",
  initialState: initialState,
  reducers: {
    setYourBlogs: (state, action) => {
      if (action.payload && action.payload !== undefined) {
        localStorage.setItem("yourBlogs", JSON.stringify(action.payload));
        state.token = action.payload.token;
      }
    },
    removeYourBlogs: (state, action) => {
      localStorage.removeItem("yourBlogs");
    },
    resetBlog: (state) => {
      state.token = null;
      localStorage.removeItem("yourBlogs");
    },
  },
});

export const { setYourBlogs, removeYourBlogs, reseYourBlogs } =
  blogSlice.actions;

export default blogSlice.reducer;
