import React, { useState } from "react";
import axios from "axios";
import { NavLink, useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { useDispatch } from "react-redux";

import signupImage from "../../assests/images/signupImage.png";
import { otpGenerator } from "../../utils/helper";
import { resetSignup, setOtp, setSignupData } from "../../store/signup";
import Navbar from "../../components/common/Navbar";

const Signup = () => {
  const [localSignupData, setLocalSignupData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    password: "",
  });

  // const signupState = useSelector((state) => state.signup);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  console.log(
    "sgnupData from localStorage is : ",
    JSON.stringify(localStorage.getItem("signupData"))
  );
  console.log(
    "otp from localStorage is : ",
    JSON.stringify(localStorage.getItem("otps"))
  );

  function changeSingupData(event) {
    setLocalSignupData((prev) => {
      return { ...prev, [event.target.name]: event.target.value };
    });
  }

  async function submitForm(event) {
    event.preventDefault();
    const { email, firstname, lastname, password } = localSignupData;
    const otp = otpGenerator();

    if (!email || !firstname || !lastname || !password) {
      toast.error("All fields are mandatory !!!!");
      return;
    }

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/send-otp", { email, otp })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (!response) {
        toast.error("Something went wrong. Please try again");
        navigate("/signup");
      }

      // console.log("Response from backend is : ", response);

      if (response?.data?.success) {
        dispatch(setSignupData(localSignupData));
        dispatch(setOtp(otp));
        toast.success("OTP has been sent successfully!!!!");
        navigate("/varify-email");
      }

      if (!response?.data?.success) {
        toast.error(response.data.message);
        dispatch(resetSignup());
        navigate("/signup");
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      toast.error("Something went wrong while signup please try again !!!!");
      dispatch(resetSignup());
      navigate("/signup");
    }
  }

  return (
    <div className="max-w-[100vw] min-h-[100%]">
      <Navbar />
      <div className="w-[95%] mx-auto flex flex-wrap gap-5 justify-center mt-14">
        <div className="w-[45%] flex flex-col items-center gap-4">
          <div className="text-blue-600 text-3xl font-bold">Signup Page</div>
          <div className="text-gray-300">Signup to generate image via text</div>
          {/* form field  */}
          <form className="w-full mt-4 flex flex-col gap-4">
            {/* Firstnae && Lastname  */}
            <div className="w-full flex justify-between gap-1">
              <div className="w-[46%] flex flex-col gap-1">
                <div className="text-gray-400">first name</div>
                <input
                  type="text"
                  name="firstname"
                  value={localSignupData.firstname}
                  onChange={changeSingupData}
                  placeholder="Enter your first name here"
                  className="rounded-md pl-2"
                />
              </div>
              <div className="w-[46%] flex flex-col gap-1">
                <div className="text-gray-400 ml-4">last name</div>
                <input
                  type="text"
                  name="lastname"
                  value={localSignupData.lastname}
                  onChange={changeSingupData}
                  placeholder="Enter your last name here"
                  className="rounded-md pl-2"
                />
              </div>
            </div>
            {/* Email  */}
            <div className="w-full flex flex-col gap-2">
              <div className="text-gray-400">Email</div>
              <input
                type="email"
                name="email"
                value={localSignupData.email}
                onChange={changeSingupData}
                placeholder="Enter your email here"
                className="w-full rounded-md pl-2"
              />
            </div>
            {/* Password  */}
            <div className="w-full flex flex-col gap-2">
              <div className="text-gray-400">Password</div>
              <input
                type="password"
                name="password"
                value={localSignupData.password}
                onChange={changeSingupData}
                placeholder="Enter your password here"
                className="w-full rounded-md pl-2"
              />
            </div>
            {/* Bttons submit dashboard login  */}
            <div className="text-yellow-400 text-sm">
              You will recieve a otp on your email to varify your email after
              clicking on submit button
            </div>
            {/* alert text for signup  */}
            <div className="flex mt-4 justify-center items-center gap-10">
              <NavLink to={"/login"}>
                <button className="text-white bg-blue-400 font-bold px-3 py-2 rounded-md">
                  Back to Dashboard
                </button>
              </NavLink>
              <button
                className="text-white bg-yellow-400 font-bold px-3 py-2 rounded-md"
                onClick={submitForm}
              >
                Submit
              </button>
              <NavLink to={"/login"}>
                <button className="text-white bg-green-600 font-bold px-3 py-2 rounded-md">
                  Login
                </button>
              </NavLink>
            </div>
          </form>
        </div>
        {/* Signup image  */}
        <div className="sm:w-[45%] min-w-[45%]">
          <img
            src={signupImage}
            alt="Signupimage"
            className="w-full h-full rounded-md"
          />
        </div>
      </div>
    </div>
  );
};

export default Signup;
