import React, { useEffect, useState } from "react";
import Navbar from "../../components/common/Navbar";
import { useSelector } from "react-redux";
import axios from "axios";
import Button from "../../components/common/Button";
import toast from "react-hot-toast";
import { NavLink } from "react-router-dom";

const GenerateImage = () => {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    prompt: "",
  });
  const [images, setImages] = useState([]);

  const authState = useSelector((state) => state.auth);
  let token = authState.token;

  async function changeFormData(event) {
    setFormData((prev) => {
      return { ...prev, [event.target.name]: event.target.value };
    });
  }

  useEffect(() => {
    async function fetchUser() {
      if (!token) {
        return;
      }
      let response;
      try {
        response = await axios
          .get("http://localhost:4000/api/v1/auth/fetch-user", {
            headers: { Authorization: `Bearer ${token}` },
          })
          .then((response1) => {
            return response1;
          })
          .catch((error) => {
            return error.response;
          });

        if (response?.data?.success) {
          // console.log(
          //   "Inside dashboard success and user is ",
          //   response.data.user
          // );
          setUser(response.data.user);
        }
      } catch (error) {
        console.error("Error while fetching user :", error);
        setUser(null);
      }
    }
    fetchUser();
  }, []);

  async function generateImageHandler(event) {
    event.preventDefault();

    const { prompt } = formData;

    if (!prompt) {
      toast.error("Please fill prompt fields !!!! ");
    }

    let response;
    try {
      response = await axios
        .post("http://localhost:4000/api/v1/auth/image/generate-image", {
          prompt,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (!response) {
        toast.error("Something went wrong. Please try again");
      }

      console.log("Response from backend is : ", response);

      if (response?.data?.success) {
        toast.success(
          "Images have been generated successfully, Please select images to save download and post !!!!"
        );
        setImages(response.data.images);
        return;
      }
      toast.error(response.data.message);
      setImages([]);
    } catch (error) {
      console.error("Error while login :", error);
      toast.error("Something went wrong while login Please try again");
    }
  }

  // Download image to local System
  async function downloadImageHandler(imageUrl) {
    // console.log("imageUrl of image that needs to be download is : ", imageUrl);

    try {
      let response = await axios
        .post("http://localhost:4000/api/v1/auth/image/download-image", {
          imageUrl,
          token,
        })
        .then((res) => {
          return res;
        })
        .catch((error) => {
          return error.response;
        });
      console.log("response from backend is : ", response);
      toast.success(
        "Images has been downloaded successfully to your local machine !!!!!"
      );
    } catch (error) {
      console.log("error : ", error);
      toast.error("Failed to download this image");
    }
  }

  // To handle post the image
  async function handlePostImage(imageUrl) {
    const prompt = formData.prompt;
    try {
      let response = await axios
        .post("http://localhost:4000/api/v1/auth/post-blog", {
          imageUrl,
          token,
          prompt,
        })
        .then((res) => {
          return res;
        })
        .catch((error) => {
          return error.response;
        });
      console.log("response from backend is : ", response);
      if (response?.data?.success) {
        toast.success(response.data.message);
        return;
      }

      toast.error("Failed to save this image, Please try again");
    } catch (error) {
      console.log("error : ", error);
      toast.error("Failed to save this image, Please try again");
    }
  }

  // To handle saved image
  async function handleSavedImages(imageUrl) {
    try {
      let response = await axios
        .post("http://localhost:4000/api/v1/auth/image/save-image", {
          imageUrl,
          token,
        })
        .then((res) => {
          return res;
        })
        .catch((error) => {
          return error.response;
        });
      console.log("response from backend is : ", response);
      if (response?.data?.success) {
        toast.success(response.data.message);
        return;
      }

      toast.error("Failed to save this image, Please try again");
    } catch (error) {
      console.log("error : ", error);
      toast.error("Failed to save this image, Please try again");
    }
  }

  return (
    <div className="min-w-[100vw] min-h-[100vh]">
      <div className="w-full h-full flex flex-col gap-8">
        <Navbar user={user} />
        <div className={`flex flex-col items-center justify-center mt-12`}>
          <div className="font-bold text-3xl text-green-600 border-b-[1px] border-green-600 pb-2">
            Generate Image
          </div>
          <div className="text-sm text-gray-400 mt-8 pt-4">
            Enter prompt to generate image , You save, download and post the
            generated image
          </div>
          <form className="w-[60%] flex flex-col mt-12 gap-2">
            <div className="flex gap-4">
              <div className="text-sm text-white">prompt</div>
              <input
                type="text"
                name="prompt"
                value={formData.prompt}
                onChange={changeFormData}
                placeholder="Enter prompt to generate image"
                className="w-full rounded-md pl-2"
              />
            </div>
            <div className="mx-auto mt-12 flex justify-between gap-12">
              <div className="" onClick={generateImageHandler}>
                <Button title={"Generate Image"} bgColor={"yellow"} />
              </div>
              <NavLink to={"/dashboard"}>
                <Button title={"Back to Dashboard"} bgColor={"blue"} />
              </NavLink>
            </div>
          </form>
        </div>
        {/* Show images  */}
        <div className="w-full h-full mx-auto flex items-center justify-center flex-wrap gap-3">
          {images &&
            images.map((image, index) => (
              <div
                key={index}
                className="w-[400px] h-[400px] relative group rounded-lg"
              >
                {/* Image */}
                <img
                  src={image}
                  alt={image.alt}
                  className="w-full h-full object-cover hover:scale-110  transition-all duration-300 rounded-md group-hover:blur-sm"
                />

                {/* Hover Overlay */}
                <div className="absolute inset-0 mb-6 flex items-end justify-evenly opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300">
                  <button
                    className="text-white bg-blue-500 px-2 py-1 rounded-md hover:bg-green-600 transition"
                    onClick={() => {
                      // console.log("Image url ", image);
                      downloadImageHandler(image);
                    }}
                  >
                    Download
                  </button>
                  <button
                    onClick={() => handlePostImage(image)}
                    className="text-white bg-purple-500 px-2 py-1 rounded-md hover:bg-green-600 transition"
                  >
                    Post This Image
                  </button>
                  <button
                    onClick={() => handleSavedImages(image)}
                    className="text-white bg-green-500 px-2 py-1 rounded-md hover:bg-green-600 transition"
                  >
                    Save this image
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default GenerateImage;
