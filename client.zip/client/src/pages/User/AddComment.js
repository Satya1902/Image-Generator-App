import { useSelector } from "react-redux";
import Navbar from "../../components/common/Navbar";
import { useEffect, useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";

function AddComment() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({ comment: "" });
  const [loading, setLoading] = useState(false);

  const authState = useSelector((state) => state.auth);
  const token = authState.token;

  const postState = useSelector((state) => state.post);
  const singlePost = postState.singlePost;
  console.log("single Post is : ", singlePost);

  async function fetchUser() {
    if (!token) {
      return;
    }
    let response;
    try {
      response = await axios
        .get("http://localhost:4000/api/v1/auth/fetch-user", {
          headers: { Authorization: `Bearer ${token}` },
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        setUser(response.data.user);
      }
    } catch (error) {
      console.error("Error while fetching user :", error);
      setUser(null);
    }
  }

  useEffect(() => {
    fetchUser();
  }, []);

  function changeFormData(event) {
    setFormData((prev) => {
      return { ...prev, [event.target.name]: event.target.value };
    });
  }

  async function addCommentHandler(blog) {
    if (!token) {
      return;
    }
    try {
      setLoading(true);
      let response = await axios
        .post("http://localhost:4000/api/v1/auth/", {
          token,
          blog,
        })
        .then((response1) => {
          return response1;
        })
        .catch((error) => {
          return error.response;
        });

      if (response?.data?.success) {
        toast.success("You have addedd the comment successfully ");
      }
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error("Error while adding the comment is : ", error);
      toast.error("Something went wrong while adding the comment");
    }
  }

  function submitFormHandler(event) {
    event.preventDefault();
    console.log("Comment from form field is : ", formData.comment);
  }

  return (
    <div className="w-[100vw] h-[100vh] overflow-hidden">
      <Navbar user={user} className="h-[10%]" />
      <div className="h-[80%] flex flex-col gap-8 mt-12">
        <div className="mx-auto text-green-400 text-3xl font-bold">
          Add Comment Page
        </div>
        <form className="flex flex-col mt-12">
          <textarea
            className="border-2 rounded-md w-[90%] mx-auto p-2"
            rows="5"
            name="comment"
            value={formData.comment}
            onChange={changeFormData}
          />
          <button
            onClick={submitFormHandler}
            className="w-[20%] bg-green-400 px-2 py-2 mt-8 font-bold mx-auto rounded-md"
          >
            Add Comment
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddComment;
