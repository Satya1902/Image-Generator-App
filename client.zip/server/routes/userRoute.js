const express = require("express");

const sendOTP = require("../controllers/user/SendOTP");
const UploadImageToCludinary = require("../controllers/user/UploadImageToCloudinary");
const varifyOTP = require("../controllers/user/VarifyOTP");
const { CreateUser } = require("../controllers/user/CreateUser");
const { fetchUser } = require("../controllers/user/CreateUser");
const LoginUser = require("../controllers/user/LoginUser");
const { Auth } = require("../middlewares/Auth");
const { createBlog, fetchAllBlogs } = require("../controllers/blog/Blog");
const fetchYourBlogs = require("../controllers/user/FetchYourBlogs");
const { CreateLike, disLike } = require("../controllers/like/LikeController");
// const

const router = express.Router();

router.post("/send-otp", sendOTP);
router.post("/varify-email", varifyOTP, CreateUser);

router.post("/login", LoginUser);
router.get("/fetch-user", Auth, fetchUser);

// To crate a blog of image and post
router.post("/post-blog", Auth, createBlog);

// To fetch All blogs
router.get("/allblogs", Auth, fetchAllBlogs);
router.get("/yourblogs", Auth, fetchYourBlogs);

// Create Like
router.post("/create-like", Auth, CreateLike);
router.post("/dislike", Auth, disLike);

// Comment section

module.exports = router;
