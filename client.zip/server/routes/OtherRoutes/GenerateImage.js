const express = require("express");
const GenerateAIImage = require("../../controllers/GenerateAIImage");

const router = express.Router();

router.get("/", GenerateAIImage);

module.exports = router;
