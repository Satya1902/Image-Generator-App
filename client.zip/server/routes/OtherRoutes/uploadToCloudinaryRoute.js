const express = require("express");
const multer = require("multer");

const UploadImageToCludinary = require("../../controllers/user/UploadImageToCloudinary");

const router = express.Router();
// Configure Multer (no local storage needed as images go directly to Cloudinary)
const storage = multer.memoryStorage(); // Temporarily store the file in memory
const upload = multer({ storage });

// Endpoint to upload an image retrieved from frontend to cloudinary
router.post("/upload", upload.single("image"), UploadImageToCludinary);

module.exports = router;
