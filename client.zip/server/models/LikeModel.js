const mongoose = require("mongoose");

// Define the Courses schema
const likeSchema = new mongoose.Schema({
  blogs: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Blog",
    },
  ],
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Export the Courses model
module.exports = mongoose.model("Like", likeSchema);
