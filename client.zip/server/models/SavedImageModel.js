const mongoose = require("mongoose");

// Define the Courses schema
const SavedImagesSchema = new mongoose.Schema({
  image: {
    type: String,
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  prompt: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Export the Courses model
module.exports = mongoose.model("SavedImage", SavedImagesSchema);
