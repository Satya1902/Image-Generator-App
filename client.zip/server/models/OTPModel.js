const mongoose = require("mongoose");

// Define the Courses schema
const otpSchema = new mongoose.Schema({
  otp: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Export the Courses model
module.exports = mongoose.model("Otp", otpSchema);
