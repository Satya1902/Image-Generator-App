const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");

const database = require("./config/database");
const { cloudinaryConnect } = require("./config/cloudinary");
// Routes
const userRoute = require("./routes/userRoute");
const imageRoute = require("./routes/imageRoute");

const app = express();
dotenv.config();
const PORT = process.env.PORT || 4000;

//middlewares of json && cors
app.use(express.json());
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);

//database connect
database.connect();

//cloudinary connection
cloudinaryConnect();

//routes
app.use("/api/v1/auth", userRoute);
app.use("/api/v1/auth/image/", imageRoute);

//def route
app.get("/", (req, res) => {
  return res.json({
    success: true,
    message: "Your server is up and running....",
  });
});

app.listen(PORT, () => {
  console.log(`App is running at ${PORT}`);
});
