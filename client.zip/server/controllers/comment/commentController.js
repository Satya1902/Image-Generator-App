const BlogModel = require("../../models/BlogModel");
const LikeModel = require("../../models/LikeModel");
const UserModel = require("../../models/UserModel");

async function AddComment(req, res) {
  try {
    const userId = req.body.user.id;
    const blogId = req.body.blog._id;
    const blog = await BlogModel.findById(blogId);

    // console.log("Userid,blogId and blog are : ", userId, blogId, blog);

    const updatedLike = await LikeModel.findOneAndUpdate(
      { user: userId },
      { $push: { blogs: blogId } }, // Push itemId into the array
      { new: true, useFindAndModify: false }
    );

    console.log("Updated Like is : ", updatedLike);

    const updatedBlog = await BlogModel.findByIdAndUpdate(
      blogId,
      { $push: { likes: userId } },
      { new: true, useFindAndModify: false }
    );

    console.log("Updated Blog is : ", updatedBlog);

    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      { $push: { likes: userId } },
      // { $push: { blogs: updatedBlog } },
      { new: true, useFindAndModify: false }
    );

    console.log("Updated User is : ", updatedUser);

    res.status(200).json({
      success: true,
      message: "You have liked this post successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error while liking the post",
    });
  }
}

async function RemoveComment(req, res) {
  try {
    const userId = req.body.user.id;
    const blogId = req.body.blog._id;
    const blog = await BlogModel.findById(blogId);

    // console.log("Userid,blogId and blog are : ", userId, blogId, blog);

    const updatedBlog = await BlogModel.findByIdAndUpdate(
      blogId,
      { $pull: { likes: userId } },
      { new: true, useFindAndModify: false }
    );

    console.log("Updated Blog is : ", updatedBlog);

    const updatedLike = await LikeModel.findOne({ user: userId });

    console.log("Updated like is : ", updatedLike);

    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
      { $pull: { likes: userId } },
      { new: true, useFindAndModify: false }
    );

    console.log("Updated User is : ", updatedUser);

    const disLiked = await LikeModel.findOneAndDelete({ user: userId });

    console.log("Updated Like is : ", disLiked);

    res.status(200).json({
      success: true,
      message: "You have disliked this post successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal server error while disliking the post",
    });
  }
}

module.exports = { AddComment, RemoveComment };
