const cloudinary = require("cloudinary").v2;
const path = require("path");
const fs = require("fs");

const image =
  "C:/Users/admin/Desktop/Full-Stack-Project/MERN/ImageGenerator/server/utils/images/Satya.jpg";

// const imageurl =
//   "https://images.unsplash.com/photo-1518134401586-70feb7eea215?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2OTA5NDN8MHwxfHNlYXJjaHwxfHwlMjJnaXJsJTIwb24lMjBtb3VudGFpbiUyMnxlbnwwfHx8fDE3MzUzOTE1ODd8MA&ixlib=rb-4.0.3&q=80&w=1080";

async function UploadImageToCloudinary(req, res) {
  try {
    const result = await cloudinary.uploader.upload(image, {
      folder: "blogapp",
    });

    return res.status(200).json({
      success: true,
      message: "Image has been uploaded to cloudinary successfully",
    });
  } catch (error) {
    console.error("error", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error while uploading image to cloudinary",
    });
  }
}

module.exports = UploadImageToCloudinary;
