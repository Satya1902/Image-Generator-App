const dotenv = require("dotenv");
const bcrypt = require("bcryptjs");

const transporter = require("../../services/MailSenderTransporter");
const OtpModel = require("../../models/OTPModel");
const UserModel = require("../../models/UserModel");
const OTPModel = require("../../models/OTPModel");

dotenv.config();

async function varifyOTP(req, res, next) {
  try {
    const { tempOtp, signupData, otp } = req.body;

    // console.log("tempOtp email and otp are", tempOtp, email, otp);

    if (!tempOtp || !signupData || !otp) {
      return res.status(400).json({
        success: false,
        message: " please share signupData , otp and tempOtp ",
      });
    }

    const email = signupData.email;

    if (tempOtp !== otp) {
      return res.status(401).json({
        success: false,
        message: " Please enter correct otp that is sent on your email ",
      });
    }

    const otpObject = await OTPModel.find({ email, otp });
    console.log("otpObject is : ", otpObject);

    //  Valiate if otp is within 5 minutes

    const otpCreatedTime = otpObject[0].createdAt;
    const currentTime = Date.now();
    const diff = currentTime - otpCreatedTime;

    console.log(
      "otpCreatedTime currentTime and difference are : ",
      otpCreatedTime,
      currentTime,
      diff
    );

    if (diff > 300000) {
      return res.status(401).json({
        success: false,
        message:
          " Your otp has been expired, Please click on resendotp and try again ",
      });
    }
    req.body.signupData = signupData;

    next();
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Internal server error , Something went wrong Varifying email ",
    });
  }
}

module.exports = varifyOTP;
