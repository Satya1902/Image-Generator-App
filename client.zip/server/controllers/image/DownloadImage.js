const dotenv = require("dotenv");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

dotenv.config();

async function downloadImage(imageUrl, outputPath) {
  try {
    // Fetch the image data
    const response = await axios({
      url: imageUrl,
      method: "GET",
      responseType: "stream", // Stream the image data
    });

    // Create a write stream to save the image
    const writer = fs.createWriteStream(outputPath);

    // Pipe the image data to the file
    response.data.pipe(writer);

    // Return a promise that resolves when the writing is complete
    return new Promise((resolve, reject) => {
      writer.on("finish", resolve);
      writer.on("error", reject);
    });
  } catch (error) {
    console.error(`Error downloading image: ${error.message}`);
  }
}

let _dirname =
  "C:/Users/admin/Desktop/Full-Stack-Project/MERN/ImageGenerator/server/DownloadedImages";

// Controller to generate Image using API from unsplashed App
const DownloadImage = async (req, res) => {
  try {
    const imageUrl = req.body.imageUrl;

    console.log("Image url is : ", imageUrl);

    const outputPath = path.join(_dirname, "image1.jpg"); // Replace with your desired output path

    downloadImage(imageUrl, outputPath)
      .then(() => console.log("Image downloaded successfully"))
      .catch((err) => {
        console.error("Error downloading image:", err);
        return res.status(500).json({
          succss: false,
          message:
            "Internal server error, Something went wrong while downloading image",
        });
      });

    return res.status(200).json({
      success: true,
      message:
        "Image has been Downloaded successfully to your loacal storage !!!!",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      succss: false,
      message:
        "Internal server error, Something went wrong while downloading image",
    });
  }
};

module.exports = DownloadImage;
