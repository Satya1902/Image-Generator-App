const cloudinary = require("cloudinary").v2;
const path = require("path");
const fs = require("fs");

//  To upload local image OR imageURL to cloudinary

let imageUrl =
  "C:/Users/admin/Desktop/Full-Stack-Project/MERN/ImageGenerator/server/utils/images/Satya.jpg";

// const imageurl =
//   "https://images.unsplash.com/photo-1518134401586-70feb7eea215?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2OTA5NDN8MHwxfHNlYXJjaHwxfHwlMjJnaXJsJTIwb24lMjBtb3VudGFpbiUyMnxlbnwwfHx8fDE3MzUzOTE1ODd8MA&ixlib=rb-4.0.3&q=80&w=1080";

async function UploadLocalImageToCloudinary(req, res, next) {
  let image = req.body.imageUrl;
  const user = req.body.user;

  if (image) {
    imageUrl = image;
  }

  console.log("Imageurl and user are : ", imageUrl, user);

  try {
    const result = await cloudinary.uploader.upload(imageUrl, {
      folder: "blogapp",
    });

    console.log("Response from cloudinary is : ", result);

    req.body.user = user;
    req.body.imageUrl = result.secure_url;

    next();
  } catch (error) {
    console.error("error", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error while uploading image to cloudinary",
    });
  }
}

module.exports = UploadLocalImageToCloudinary;
